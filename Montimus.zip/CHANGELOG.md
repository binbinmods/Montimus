# 0.1.1

Nerfed Montshek's damage

Nerfed all bosses speed and resists

# 0.1.0

Initial pre-release.
